'use client'

import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { BarChart, Users, Utensils, CheckCircle, AlertCircle, Download, RefreshCw, Lock, ArrowLeft } from 'lucide-react'
import DefaultBackground from '../components/layout/default-background'

interface SurveyData {
  nik: string
  ktp: string
  name: string
  department: string
  sex: string
  option_a: boolean
  option_b: boolean
  date_verified: string
}

// Mock survey data - in real app this would come from API/database
const mockSurveyData: SurveyData[] = [
  {
    nik: "YJ1_000143",
    ktp: "3202162408820003",
    name: "DEDE MASHAN",
    department: "Mekanik",
    sex: "Male",
    option_a: true,
    option_b: false,
    date_verified: "2024-01-15T10:30:00Z"
  },
  {
    nik: "YJ1_000144",
    ktp: "3202162508820004",
    name: "SITI NURHALIZA",
    department: "Produksi",
    sex: "Female",
    option_a: false,
    option_b: true,
    date_verified: "2024-01-15T11:15:00Z"
  }
  },
  {
    nik: "YJ1_000145",
    ktp: "3202162608820005",
    name: "AHMAD RIFAI",
    department: "Quality Control",
    sex: "Male",
    option_a: true,
    option_b: false,
    date_verified: "2024-01-15T14:20:00Z"
  }
]

export default function Dashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [passkey, setPasskey] = useState('')
  const [error, setError] = useState('')
  const [surveyData, setSurveyData] = useState<SurveyData[]>([])

  useEffect(() => {
    // Check if authenticated via localStorage or passkey in URL
    const urlParams = new URLSearchParams(window.location.search)
    const urlPasskey = urlParams.get('passkey')
    
    // Also check sessionStorage for data from survey page
    const storedData = sessionStorage.getItem('surveyData')
    
    if (urlPasskey === '0000' || storedData) {
      setIsAuthenticated(true)
      // Use stored data if available, otherwise use mock data
      const dataToUse = storedData ? JSON.parse(storedData) : mockSurveyData
      setSurveyData(dataToUse)
    }
    }
  }, [])

  const handleLogin = () => {
    setError('')
    if (passkey === '0000') {
      setIsAuthenticated(true)
      setSurveyData(mockSurveyData)
    } else {
      setError('Passkey salah. Silakan coba lagi.')
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setPasskey('')
    setError('')
    // Clear sessionStorage and redirect to survey page
    sessionStorage.removeItem('surveyData')
    window.location.href = '/yongjinone/survey/canteen'
  }

  const handleExport = () => {
    const csvContent = [
      ['NIK', 'KTP', 'Nama', 'Department', 'Jenis Kelamin', 'Pilihan', 'Tanggal Verifikasi'],
      ...surveyData.map(data => [
        data.nik,
        data.ktp,
        data.name,
        data.department,
        data.sex,
        data.option_a ? 'Meja Makan' : 'Duduk di Lantai',
        new Date(data.date_verified).toLocaleString('id-ID')
      ])
      ]).map(row => row.join(',')).join('\n')
    ]

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `survey_kantin_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

    const totalVotes = surveyData.length
    const optionAVotes = surveyData.filter(d => d.option_a).length
    const optionBVotes = surveyData.filter(d => d.option_b).length
    const optionAPercentage = totalVotes > 0 ? (optionAVotes / totalVotes * 100).toFixed(1) : '0'
    const optionBPercentage = totalVotes > 0 ? (optionBVotes / totalVotes * 100).toFixed(1) : '0'

  if (!isAuthenticated) {
    return (
      <DefaultBackground>
        <div className="flex items-center justify-center h-screen p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="w-full max-w-md"
          >
            <Card className="shadow-lg">
              <CardHeader className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 text-white flex items-center justify-center">
                  <Lock className="w-8 h-8" />
                </div>
                <CardTitle className="text-xl">Dashboard Access</CardTitle>
                <CardDescription>
                  Masukkan passkey untuk mengakses dashboard
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Input
                    type="password"
                    value={passkey}
                    onChange={(e) => setPasskey(e.target.value)}
                    placeholder="Enter passkey"
                    className="w-full"
                    maxLength={4}
                  />
                </div>

                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg"
                  >
                    <AlertCircle className="w-4 h-4 text-red-500" />
                    <span className="text-sm text-red-700 dark:text-red-400">{error}</span>
                  </motion.div>
                )}

                <Button
                  onClick={handleLogin}
                  disabled={!passkey.trim()}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                >
                  Access Dashboard
                </Button>
                
                <div className="text-center">
                  <Button
                    variant="ghost"
                    onClick={() => window.location.href = '/yongjinone/survey/canteen'}
                    className="text-sm"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Kembali ke Survey
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </DefaultBackground>
    )
  }

  return (
    <DefaultBackground>
      <div className="p-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-6"
        >
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 text-white flex items-center justify-center">
                  <BarChart className="w-6 h-6" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">
                    Dashboard Survey Kantin
                  </h1>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    Hasil voting fasilitas kantin Yongjinone
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleExport}
                  className="flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Export
                </Button>
                <Button
                  variant="outline"
                  onClick={handleLogout}
                  className="flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
      </Header>

      {/* Stats Cards */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="max-w-7xl mx-auto mb-6"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Total Votes</p>
                  <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{totalVotes}</p>
                </div>
                <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </div>
          </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Meja Makan</p>
                  <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{optionAVotes}</p>
                  <p className="text-sm text-blue-600 dark:text-blue-400">{optionAPercentage}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Duduk di Lantai</p>
                  <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{optionBVotes}</p>
                  <p className="text-sm text-purple-600 dark:text-purple-400">{optionBPercentage}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <RefreshCw className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Last Update</p>
                  <p className="text-lg font-bold text-slate-800 dark:text-slate-100">
                    {surveyData.length > 0 
                      ? new Date(surveyData[surveyData.length - 1].date_verified).toLocaleDateString('id-ID')
                      : 'No data'
                    }
                  </p>
                </div>
                <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <RefreshCw className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>

      {/* Chart Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="max-w-7xl mx-auto mb-6"
      >
        <Card>
          <CardHeader>
            <CardTitle>Hasil Voting</CardTitle>
            <CardDescription>Distribusi pilihan fasilitas kantin</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Meja Makan</span>
              <span className="text-sm text-blue-600 dark:text-blue-400">{optionAPercentage}% ({optionAVotes} votes)</span>
              </div>
              <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-4">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${optionAPercentage}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                  className="h-4 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full"
                />
              </motion.div>
            </div>
              </div>
            </div>

              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Duduk di Lantai</span>
                  <span className="text-sm text-purple-600 dark:text-purple-400">{optionBPercentage}% ({optionBVotes} votes)</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </Card>
      </motion.div>

      {/* Data Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="max-w-7xl mx-auto mb-6"
      >
        <Card>
          <CardHeader>
            <CardTitle>Data Peserta</CardTitle>
            <CardDescription>Detail voting setiap peserta</CardDescription>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left p-3 font-medium text-slate-700 dark:text-slate-300">NIK</th>
                  <th className="text-left p-3 font-medium text-slate-700 dark:text-slate-300">Nama</th>
                  <th className="text-left p-3 font-medium text-slate-700 dark:text-slate-300">Department</th>
                  <th className="text-left p-3 font-medium text-slate-700 dark:text-slate-300">Pilihan</th>
                  </th>
                </tr>
                </thead>
                <tbody>
                  <AnimatePresence>
                    {surveyData.map((data, index) => (
                      <motion.tr
                        key={data.nik}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{
                          x: { type: "spring", stiffness: 300, damping: 30 },
                          opacity: { duration: 0.3 },
                          rotateY: { duration: 0.6 }
                        }}
                        exit={{ opacity: 0, x: 20 }}
                        className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                        }}
                      >
                        <td className="p-3">{data.nik}</td>
                        <td className="p-3 font-medium">{data.name}</td>
                        <td className="p-3">{data.department}</td>
                        <td className="p-3">
                          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs ${
                            data.option_a 
                              ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30' 
                              : 'bg-purple-100 text-purple-700 dark:bg-purple-900/30'
                          }`}>
                            {data.option_a ? (
                              <Utensils className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                            ) : (
                              <Users className="w-3 h-3 text-purple-600 dark:text-purple-400" />
                            )}
                          </span>
                        </td>
                        </td>
                        <td className="p-3">
                          <span className="text-xs text-slate-600 dark:text-slate-400">Pilihan:</span>
                        </td>
                        </td>
                      </motion.tr>
                    ))
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </Card>
      </motion.div>
    </DefaultBackground>
    )
  )
}