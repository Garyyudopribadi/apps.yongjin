'use client'

import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  DefaultBackground,
  ThumbsUpAnimation,
  SurveyForm,
  ParticipantInfo,
  VotingOptions,
  SubmitButton,
  Success,
  SurveyHeader,
  DashboardButton,
  DashboardAccess,
  mockParticipants,
  type Participant
} from '../components'

interface SurveyData {
  nik: string
  ktp: string
  name: string
  department: string
  sex: string
  option_a: boolean
  option_b: boolean
  date_verified: string
}

// Mock survey data storage
let mockSurveyData: SurveyData[] = []

export default function CanteenSurvey() {
  const [inputValue, setInputValue] = useState('')
  const [currentParticipant, setCurrentParticipant] = useState<Participant | null>(null)
  const [selectedOption, setSelectedOption] = useState<'a' | 'b' | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showThumbsUpAnimation, setShowThumbsUpAnimation] = useState(false)
  const [error, setError] = useState('')
  const [step, setStep] = useState<'input' | 'voting' | 'success'>('input')
  const [showDashboardModal, setShowDashboardModal] = useState(false)
  const [passkey, setPasskey] = useState('')
  const [dashboardError, setDashboardError] = useState('')

  const validateParticipant = () => {
    setError('')
    const trimmedInput = inputValue.trim()
    
    const participant = mockParticipants.find(
      p => p.nik === trimmedInput || p.ktp === trimmedInput
    )

    if (participant) {
      // Check if already voted
      const existingVote = mockSurveyData.find(
        s => s.nik === participant.nik && s.ktp === participant.ktp
      )
      
      if (existingVote) {
        setError('Anda sudah melakukan voting sebelumnya.')
        return
      }

      setCurrentParticipant(participant)
      setStep('voting')
    } else {
      setError('Data tidak ditemukan. Silakan periksa kembali NIK atau nomor KTP Anda.')
    }
  }

  const handleVote = (option: 'a' | 'b') => {
    setSelectedOption(option)
    setShowThumbsUpAnimation(true)
    setTimeout(() => setShowThumbsUpAnimation(false), 2000)
  }

  const submitVote = () => {
    if (!selectedOption || !currentParticipant) return

    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      const surveyEntry: SurveyData = {
        nik: currentParticipant.nik,
        ktp: currentParticipant.ktp,
        name: currentParticipant.name,
        department: currentParticipant.department,
        sex: currentParticipant.sex,
        option_a: selectedOption === 'a',
        option_b: selectedOption === 'b',
        date_verified: new Date().toISOString()
      }

      mockSurveyData.push(surveyEntry)
      console.log('Survey Data:', mockSurveyData)
      
      setIsSubmitting(false)
      setStep('success')
    }, 1000)
  }

  const resetForm = () => {
    setInputValue('')
    setCurrentParticipant(null)
    setSelectedOption(null)
    setError('')
    setStep('input')
  }

  const handleDashboardAccess = () => {
    setDashboardError('')
    if (passkey === '0000') {
      // Redirect to dashboard with survey data
      // Store survey data in sessionStorage for dashboard to access
      sessionStorage.setItem('surveyData', JSON.stringify(mockSurveyData))
      window.location.href = '/yongjinone/survey/canteen/dashboard'
    } else {
      setDashboardError('Passkey salah. Silakan coba lagi.')
    }
  }

  return (
    <DefaultBackground>
      <ThumbsUpAnimation trigger={showThumbsUpAnimation} />
      
      <div className="min-h-screen flex flex-col justify-center px-3 sm:px-4 py-4">
        <div className="max-w-sm mx-auto w-full">
          <SurveyHeader />
          
          {/* Input Step */}
          {step === 'input' && (
            <SurveyForm
              inputValue={inputValue}
              setInputValue={setInputValue}
              error={error}
              validateParticipant={validateParticipant}
            />
          )}

          {/* Voting Step */}
          {step === 'voting' && currentParticipant && (
            <div className="space-y-3">
              <ParticipantInfo participant={currentParticipant} />
              <VotingOptions
                selectedOption={selectedOption}
                onVote={handleVote}
                isSubmitting={isSubmitting}
              />
              <SubmitButton
                selectedOption={selectedOption}
                isSubmitting={isSubmitting}
                onSubmit={submitVote}
              />
            </div>
          )}

            {/* Success Step */}
          {step === 'success' && (
            <Success onReset={resetForm} />
          )}
        </div>
      </div>

      {/* Dashboard Floating Button */}
      <DashboardButton 
        onClick={() => setShowDashboardModal(true)}
        showModal={!showDashboardModal}
      />

      {/* Dashboard Modal */}
      {showDashboardModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="w-full max-w-sm"
          >
            <DashboardAccess
              passkey={passkey}
              setPasskey={setPasskey}
              dashboardError={dashboardError}
              onAccess={handleDashboardAccess}
              onBack={() => setShowDashboardModal(false)}
            />
          </motion.div>
        </div>
      )}
    </DefaultBackground>
  )
}